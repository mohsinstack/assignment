import InputField from './InputField';

const BasicItems = ({ basic, onBasicChange,errors  }) => {
  const handleChange = (e) => {
    const { name, value } = e.target;
    onBasicChange({ ...basic, [name]: value });
  };
  

  return (
    <div className='basicinfo'>
    <div className="form-group half-width">
      <InputField
        label="First Name"
        type="text"
        name="firstname"
        className="form-control half"
        value={basic.firstname}
        onChange={handleChange}
        maxLength="20"
        errorMessage={errors.firstname}
      />
      <InputField
        label="Last Name"
        type="text"
        name="lastname"
        className="form-control half"
        value={basic.lastname}
        onChange={handleChange}
        maxLength="20"
        errorMessage={errors.lastname}
      />
        </div>
      <InputField
        label="Email"
        type="email"
        name="email"
        value={basic.email}
        className="form-control"
        onChange={handleChange}
        pattern="^[^\s@]+@[^\s@]+\.[^\s@]+$" 
        errorMessage={errors.email}
      />
    </div>
  
  );
};

export default BasicItems;
