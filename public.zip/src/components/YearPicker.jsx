import React from 'react';
import { useState } from 'react';
function YearPicker({ selectedYear, label, name, onChange, startYear = 1900, endYear = new Date().getFullYear() }) {
  const years = Array.from({ length: endYear - startYear + 1 }, (v, i) => startYear + i);
  const [year, setYear] = useState(new Date().getFullYear());
  const handleYearChange = (e) => {
    setYear(e.target.value);
  };
  return (
    <div className='half'>
    <label className="label">{label}</label>
    <select className="" name={name} value={selectedYear} onChange={onChange} >
      {years.map(year => (
        <option key={year} value={year}>
          {year}
        </option>
      ))}
    </select>
    </div>
  );
}

export default YearPicker;
