import { useState, useEffect } from 'react';
import InputField from './InputField';
import YearPicker from './YearPicker';

const EducationItem = ({ education, onEducationChange, onRemove, index, errors }) => {
    const [year, setYear] = useState(education.passoutYear || new Date().getFullYear());
    
    useEffect(() => {
      setYear(education.passoutYear || new Date().getFullYear());
    }, [education.passoutYear]);

    const handleChange = (e) => {
        onEducationChange(index, e);
    };

    return (
      <div className='repeater'>
        <div className="form-group">
          <InputField   
            label="Institution Name"
            type="text"
            name="institutionName"
            value={education.institutionName}
            onChange={handleChange}
            maxLength="50"
            errorMessage={errors?.institutionName}
          />
          <div className='form-group half-width'>
            <YearPicker 
              label="Passout Year"
              name="passoutYear"
              className="form-control half"
              selectedYear={year} 
              onChange={handleChange} 
              startYear={1980} 
              endYear={new Date().getFullYear() + 4} 
             
            />
            <div className='half'>
           
            <InputField   
                label="CGPI Name"
                type="text"
                name="cgpi"
                pattern="^\d*(\.\d+)?$"
                value={education.cgpi}
                onChange={handleChange}
                maxLength="50"
                errorMessage={errors?.cgpi}
            />
            
            </div>
          </div>
          <div className="form-group">
            {index > 0 && (
              <button
                type="button"
                onClick={() => onRemove(index)}
                className="btn rmvbtn"
              >
                Remove
              </button>
            )}
          </div>
        </div>
        <hr />
      </div>
    );
};

export default EducationItem;
