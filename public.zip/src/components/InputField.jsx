const InputField = ({ label, type, name, value, className, onChange, placeholder, pattern, maxLength, errorMessage }) => {
    return (
        <div>
            <label className="label">{label}</label>
            <input
                type={type}
                name={name}
                value={value}
                onChange={onChange}
                placeholder={placeholder}
                className= {className}
                pattern={pattern}
                maxLength={maxLength}
                aria-describedby={errorMessage ? `${name}-error` : undefined}
            />
            {errorMessage && (
                <p className="errortext" id={`${name}-error`}>{errorMessage}</p>
            )}
        </div>
    );
};

export default InputField;
