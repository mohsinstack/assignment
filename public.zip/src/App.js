import React, { useEffect, useState } from 'react';
import EducationItem from './components/EducationItem';
import BasicItems from './components/BasicItems';
import './App.css';

const Form = () => {

  const [basicInfo, setBasicInfo] = useState({
    firstname: '',
    lastname: '',
    email: ''
  });

  const [educations, setEducations] = useState([
    { institutionName: '', passoutYear: '', cgpi: '' }
  ]);

  const [errors, setErrors] = useState({
    firstname: '',
    lastname: '',
    email: '',
    educations: educations.map(() => ({
        institutionName: '',
        passoutYear: '',
        cgpi: ''
    }))
});

  const [submitted, setSubmitted] = useState(false);
  useEffect(()=>{
    console.log("Registered")
  }, [submitted]);

  const handleBasicInfoChange = (basicInfoUpdate) => {
    setBasicInfo(basicInfoUpdate);
  };

  const handleEducationChange = (index, e) => {
    const values = [...educations];
    values[index][e.target.name] = e.target.value;
    setEducations(values);
  };

  const addEducation = () => {
    setEducations([...educations, { institutionName: '', passoutYear: '', cgpi: '' }]);
  };

  const removeEducation = (index) => {
    const values = [...educations];
    values.splice(index, 1);
    setEducations(values);
  };

  const validateFirstName = (name) => name.length <= 20;
  const validateLastName = (name) => name.length <= 20;
  const validateEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  const validateInstitutionName = (name) => name.length <= 50;
  const validatePassoutYear = (year) => /^\d{4}$/.test(year) && year <= new Date().getFullYear();
  const validateCGPIScore = (score) => !isNaN(score) && score.toString().match(/^\d*(\.\d+)?$/);

  const handleSubmit = (e) => {
    e.preventDefault();
    
    let newErrors = {
        ...errors,
        educations: educations.map(() => ({
            institutionName: '',
            passoutYear: '',
            cgpi: ''
        }))
    }
    newErrors.firstname = !basicInfo.firstname ? 'First name cannot be blank.' : validateFirstName(basicInfo.firstname) ? '' : 'First name must be up to 20 characters.';
    newErrors.lastname = !basicInfo.lastname ? 'Last name cannot be blank.' : validateLastName(basicInfo.lastname) ? '' : 'Last name must be up to 20 characters.';
    newErrors.email = !basicInfo.email ? 'Email cannot be blank.' : validateEmail(basicInfo.email) ? '' : 'Please enter a valid email address.';

    
    const educationErrors = educations.map((edu) => ({
        institutionName: !edu.institutionName ? 'Institution name cannot be blank.' : validateInstitutionName(edu.institutionName) ? '' : 'Institution name must be up to 50 characters.',
        passoutYear: !edu.passoutYear ? 'Passout year cannot be blank.' : validatePassoutYear(edu.passoutYear) ? '' : 'Please enter a valid passout year.',
        cgpi: !edu.cgpi ? 'CGPI/Score cannot be blank.' : validateCGPIScore(edu.cgpi) ? '' : 'Please enter a valid CGPI/Score.'
    }));

    newErrors.educations = educationErrors;

    setErrors(newErrors);

    
    const hasBasicInfoErrors = newErrors.firstname || newErrors.lastname || newErrors.email;
    const hasEducationErrors = newErrors.educations.some(edu => edu.institutionName || edu.passoutYear || edu.cgpi);

    if (hasBasicInfoErrors || hasEducationErrors) {
     // console.log(hasEducationErrors)
    console.log(educations)
      return; 
    }
    setSubmitted(true);
    console.log('Form Submitted:', { basicInfo, educations });
};


  return (
    <div className='container'>
      {(submitted)? <h2>Hello {basicInfo.firstname} {basicInfo.lastname}, You have been Registered Successfully </h2>: ''}
      <form onSubmit={handleSubmit}>
        <h2 className="subtitle">Basic Information</h2>
        <BasicItems
          basic={basicInfo}
          onBasicChange={handleBasicInfoChange}
          errors={errors}
        />

        <h2 className="subtitle">Educational Background</h2>
       
        {educations.map((education, index) => (
            <EducationItem
                key={index}
                index={index}
                education={education}
                onEducationChange={handleEducationChange}
                onRemove={removeEducation}
                errors={errors.educations[index]} 
            />
        ))}

        <button
          type="button"
          onClick={addEducation}
          className="btn addmorebtn"
        >
          Add More
        </button>
        <br />
        <button
          type="submit"
          className="btn btn-submit"
        >
          Submit
        </button>
      </form>
    </div>
  );
};

export default Form;
